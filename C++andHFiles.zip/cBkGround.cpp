/*
=================
cRocket.cpp
- Header file for class definition - IMPLEMENTATION
=================
*/
#include "cBkGround.h"

void cBkGround::render()
{
	
}
/*
=================================================================
Update the sprite position
=================================================================
*/

void cBkGround::update()
{
}
